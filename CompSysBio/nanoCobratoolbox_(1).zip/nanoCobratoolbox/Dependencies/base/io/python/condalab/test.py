
import sys
print("The python executable I am using is located at:")
print(sys.executable)