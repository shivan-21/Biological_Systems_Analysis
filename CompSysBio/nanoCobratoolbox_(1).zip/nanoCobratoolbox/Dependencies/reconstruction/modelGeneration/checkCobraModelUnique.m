function [model, isUnique] = checkCobraModelUnique(model, renameFlag)
% Checks uniqueness of reaction and metabolite names
%
% USAGE:
%
%    model = checkCobraModelUnique(model, renameFlag)
%
% INPUT:
%    model:         COBRA model structure
%
% OPTIONAL INPUT:
%    renameFlag:    Renames non-unique reaction names and metabolites
%                   (Default = false)
%
% OUTPUT:
%    model:         COBRA model structure
%    isUnique:      true if the model has unique reaction and metabolite names
%
% .. Authors:
%       - Markus Herrgard 10/17/07
%       - Stefania Magnusdottir 07/02/17 - Replace use of findRxnIDs and findMetIDs, both only return one index even if more are found in model.

if nargin < 2
    renameFlag = false;
end

isUnique = true;
[rxnName, rxnCnt] = countUnique(model.rxns);
rxnInd = find(rxnCnt > 1);
if ~isempty(rxnInd)
    isUnique = false;
    fprintf('Model contains non-unique reaction names - consider renaming reactions using checkCobraModelUnique\n');
    for i = 1:length(rxnInd)
        thisRxnName = rxnName{rxnInd(i)};
        fprintf('%s\t%d\n', thisRxnName, rxnCnt(rxnInd(i)));
        if renameFlag
            fprintf('Renaming non-unique reactions\n');
            rxnIDs = find(ismember(model.rxns, thisRxnName));
            for j = 1:length(rxnIDs)
                model.rxns{rxnIDs(j)} = [thisRxnName '_' num2str(j)];
                fprintf('%s\n', model.rxns{rxnIDs(j)});
            end
        end
    end
end

[metName, metCnt] = countUnique(model.mets);
metInd = find(metCnt > 1);
if ~isempty(metInd)
    isUnique = false;
    fprintf('Model contains non-unique metabolite names - consider renaming metabolites using checkCobraModelUnique\n');
    for i = 1:length(metInd)
        thisMetName = metName{metInd(i)};
        fprintf('%s\n', thisMetName);
        if renameFlag
            fprintf('Renaming non-unique metabolites\n');
            metIDs = find(ismember(model.mets, thisMetName));
            for j = 1:length(metIDs)
                model.mets{metIDs(j)} = [thisMetName '_' num2str(j)];
                fprintf('%s\n', model.mets{metIDs(j)});
            end
        end
    end
end
